import random

class Plant():
    def __init__(self, name, health, damage):
        self._name = name
        self.health = health
        self._damage = damage

    def attack_zombie(self, zombie):
        zombie.health -= self._damage
        print(f"{self._name} attacks {zombie._name} for {self._damage} damage!")

class Zombie():
    def __init__(self, name, health, damage):
        self._name = name
        self.health = health
        self._damage = damage

    def attack_plant(self, plant):
        plant.health -= self._damage
        print(f"{self._name} attacks {plant._name} for {self._damage} damage!")

inputname1 = input("Enter the name of the first plant: ")
plant1 = Plant(inputname1, random.randint(15, 30), random.randint(2, 10))

inputname2 = input("Enter the name of the second plant: ")
plant2 = Plant(inputname2, random.randint(15, 30), random.randint(2, 10))

zombie1 = Zombie("Maeri" if random.randint(0,1) == 0 else "Gab", random.randint(30, 80), random.randint(5,15))

print("Welcome to Plants vs Zombies!")
print(f"The first plant, {plant1._name}, has {plant1.health} health and {plant1._damage} damage.")
print(f"The second plant, {plant2._name}, has {plant2.health} health and {plant2._damage} damage.")
print(f"The zombie, {zombie1._name}, has {zombie1.health} health and {zombie1._damage} damage.")

def main():
    distance = random.randint(4, 8)
    step = 0
    while (plant1.health > 0 or plant2.health > 0) and zombie1.health > 0:
        print("______________________________________")
        step += 1
        print(f"Step {step}:")
        print(f"The first plant, {plant1._name}, currently has {plant1.health} health.")
        print(f"The second plant, {plant2._name}, currently has {plant2.health} health.")
        print(f"The zombie, {zombie1._name}, currently has {zombie1.health} health.")
        print(f"The distance between the plants and the zombie is {distance} units.")
        
        if distance > 0:
            if plant1.health > 0:
                plant1.attack_zombie(zombie1)
            if plant2.health > 0:
                plant2.attack_zombie(zombie1)

            distance -= 1

        else:
            if plant1.health <= 0:
                zombie1.attack_plant(plant2)
                distance = random.randint(2, 6)
            else: 
                zombie1.attack_plant(plant1)
            

    if (plant1.health >= 0 or plant2.health >= 0) and zombie1.health <= 0:
        print("The plants have defeated the zombie!")
    elif (plant1.health <= 0 and plant2.health <= 0) and zombie1.health > 0:
        print("The zombie has defeated the plants!")
    else:
        print("The battle ended in a draw!")

main()